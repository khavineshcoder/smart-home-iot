================================================================================
  SMART HOME IoT – PURE HTML / CSS / JS VERSION
  Diploma Final Year Project Style
================================================================================

No public demo accounts are created.
Only authorised system administrators are pre-seeded.

HOW TO USE (Frontend prototype)
-------------------------------
1. Open the folder "smart-home-iot-html"
2. Double-click index.html (or open with any modern browser)
3. If you used an older version before, clear localStorage once:
   Press F12 → Console → type: localStorage.clear() → Enter → refresh

ADMINISTRATOR ACCOUNTS (system-managed)
---------------------------------------
These three emails are the only pre-created accounts.
Each has a unique strong password.

  SUPER ADMINISTRATOR (can add/delete Admin, Owner, Tenant)
  1. Email    : khavinesh424835@gmail.com
     Password : Kh@viNe5h#4248$IoT

  ADMINISTRATORS (can add/delete Owner & Tenant only)
  2. Email    : eevannesswaran@gmail.com
     Password : Ev@nNess#2026$IoT!

  3. Email    : etwo999@gmail.com
     Password : EtWo999#Secure$26!

USER MANAGEMENT
---------------
  Super Admin  → Create / deactivate / delete Admin, Owner, Tenant
  Admin        → Create / deactivate / delete Owner, Tenant only
  Owner/Tenant → Register via public form (or created by staff)

DEVICES (aligned with ESP32 firmware)
-------------------------------------
  Room 1 Light  GPIO26
  Room 1 Fan    GPIO27
  Room 2 Light  GPIO32
  Room 2 Fan    GPIO33
  Presence alerts → Telegram notification

OWNER & TENANT ACCOUNTS
-----------------------
Owners and Tenants must register themselves via "Create an account".
No Owner or Tenant accounts are pre-created.

Suggested strong passwords (use a DIFFERENT password for every account):

  Owner example  : Own3r#House$2026!x
  Tenant example : T3n@ntSafe#26!Qy

Rules:
  • At least 8 characters
  • Must contain uppercase, lowercase and a number
  • Never reuse the same password across accounts

OWNER REGISTRATION
------------------
When registering as Owner you must enter:
  • Number of houses for rent (how many units you are renting out)
  • Primary house address

This number is stored and shown on the Owner dashboard and in the
Admin “Houses” table.

Tenant registration only needs the exact address that an Owner has
already registered.

DATABASE & SERVER ANALYSIS (added)
----------------------------------
This folder now includes formal documentation for the diploma report:

  database/database.sql
      Complete MySQL / MariaDB schema (XAMPP compatible).
      Tables: users, houses, devices, login_attempts,
              activity_logs, security_alerts, sensor_readings
      Includes house_count for Owner multi-unit declaration.
      Import into phpMyAdmin or run via mysql CLI.

  docs/SERVER_ANALYSIS.txt
      Full server & database analysis document covering:
        • System architecture (3-tier)
        • Entity–relationship summary
        • Table descriptions & normalisation
        • Mapping localStorage → MySQL
        • Role-based access control matrix
        • Security analysis (SQL injection, CSRF, etc.)
        • Key data-flow use cases
        • Prototype vs full server comparison

Use these two files in your project report / viva as the
Database Design and System Analysis chapters.

FOLDER STRUCTURE
----------------
smart-home-iot-html/
├── index.html              Login & Register
├── dashboard.html          Main dashboard
├── assets/
│   ├── style.css
│   └── app.js
├── database/
│   └── database.sql        MySQL schema
├── docs/
│   └── SERVER_ANALYSIS.txt Architecture & DB analysis
└── README.txt

FEATURES
--------
• Login & Registration (localStorage prototype)
• Role-based device control (Admin / Owner / Tenant)
• Owner declares number of houses for rent + address
• Presence sensors (ultrasonic) + Telegram alerts
• Security alerts + Activity logs
• Admin: user management & houses list
• Responsive modern dark UI
• Offline-capable frontend + formal DB/server design docs
================================================================================
