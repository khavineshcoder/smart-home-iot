/**
 * Smart Home IoT Management System
 * Web control centre (aligned with ESP32: 2 rooms, Telegram alerts)
 * Roles: super_admin | admin | owner | tenant
 */

'use strict';

const STORAGE = {
  users: 'shi_users',
  houses: 'shi_houses',
  devices: 'shi_devices',
  alerts: 'shi_alerts',
  activity: 'shi_activity',
  session: 'shi_session',
  telegram: 'shi_telegram'
};

function load(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function save(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

function now() {
  return new Date().toLocaleString('en-MY', { hour12: false });
}

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function esc(str) {
  if (str == null) return '';
  const d = document.createElement('div');
  d.textContent = String(str);
  return d.innerHTML;
}

function initSystemAdmins() {
  let users = load(STORAGE.users, null);
  if (users && users.length) return;

  users = [
    {
      id: 'u_super',
      name: 'Khavinesh',
      email: 'khavinesh424835@gmail.com',
      password: 'Kh@viNe5h#4248$IoT',
      role: 'super_admin',
      houseId: null,
      houseCount: 0,
      active: true
    },
    {
      id: 'u_admin_1',
      name: 'Eevannesswaran',
      email: 'eevannesswaran@gmail.com',
      password: 'Ev@nNess#2026$IoT!',
      role: 'admin',
      houseId: null,
      houseCount: 0,
      active: true
    },
    {
      id: 'u_admin_2',
      name: 'Etwo',
      email: 'etwo999@gmail.com',
      password: 'EtWo999#Secure$26!',
      role: 'admin',
      houseId: null,
      houseCount: 0,
      active: true
    }
  ];
  save(STORAGE.users, users);
  save(STORAGE.houses, []);
  save(STORAGE.devices, { r1_light: 0, r1_fan: 0, r2_light: 0, r2_fan: 0 });
  save(STORAGE.alerts, []);
  save(STORAGE.activity, [{
    id: uid(),
    action: 'SYSTEM',
    details: 'Control centre initialised',
    time: now(),
    user: 'System'
  }]);
}

function getCurrentUser() {
  return load(STORAGE.session, null);
}

function setSession(user) {
  const safe = { ...user };
  delete safe.password;
  save(STORAGE.session, safe);
}

function logout() {
  localStorage.removeItem(STORAGE.session);
  window.location.href = 'index.html';
}

function showLogin() {
  document.getElementById('loginCard').style.display = '';
  document.getElementById('registerCard').style.display = 'none';
}

function showRegister() {
  document.getElementById('loginCard').style.display = 'none';
  document.getElementById('registerCard').style.display = '';
}

function showAlert(elId, msg, type) {
  const el = document.getElementById(elId);
  if (!el) return;
  el.className = 'alert ' + type;
  el.textContent = msg;
  el.style.display = 'block';
}

function roleLabel(role) {
  return {
    super_admin: 'Super Administrator',
    admin: 'Administrator',
    owner: 'House Owner',
    tenant: 'Tenant'
  }[role] || role;
}

function canManageAdmins(role) {
  return role === 'super_admin';
}

function canManageUsers(role) {
  return role === 'super_admin' || role === 'admin';
}

function getPermissions(role) {
  if (['super_admin', 'admin', 'owner', 'tenant'].includes(role)) {
    return { r1_light: true, r1_fan: true, r2_light: true, r2_fan: true };
  }
  return { r1_light: false, r1_fan: false, r2_light: false, r2_fan: false };
}

function updateRoleHint() {
  const role = document.getElementById('regRole')?.value;
  const hint = document.getElementById('roleHint');
  const countWrap = document.getElementById('houseCountWrap');
  const houseCountInput = document.getElementById('regHouseCount');
  const addressLabel = document.getElementById('addressLabel');
  if (role === 'owner') {
    if (countWrap) countWrap.style.display = '';
    if (houseCountInput) houseCountInput.required = true;
    if (addressLabel) addressLabel.textContent = 'Primary house address';
    if (hint) hint.innerHTML = '<strong>Owner registration</strong><span>Enter how many houses you rent out and the primary address.</span>';
  } else if (role === 'tenant') {
    if (countWrap) countWrap.style.display = 'none';
    if (houseCountInput) { houseCountInput.required = false; houseCountInput.value = ''; }
    if (addressLabel) addressLabel.textContent = 'House address (must match Owner)';
    if (hint) hint.innerHTML = '<strong>Tenant registration</strong><span>Enter the exact address already registered by an Owner.</span>';
  } else {
    if (countWrap) countWrap.style.display = 'none';
    if (houseCountInput) houseCountInput.required = false;
    if (hint) hint.innerHTML = '<strong>Account registration</strong><span>Owners claim an address. Tenants join an existing Owner address.</span>';
  }
}

function handleLogin(e) {
  e.preventDefault();
  const email = document.getElementById('loginEmail').value.trim().toLowerCase();
  const pass = document.getElementById('loginPassword').value;
  const users = load(STORAGE.users, []);
  const user = users.find(u => u.email === email && u.password === pass);
  if (!user) {
    showAlert('loginAlert', 'Invalid email or password.', 'danger');
    return false;
  }
  if (!user.active) {
    showAlert('loginAlert', 'This account has been deactivated.', 'danger');
    return false;
  }
  setSession(user);
  logActivity('LOGIN', 'Successful login', user.name);
  window.location.href = 'dashboard.html';
  return false;
}

function handleRegister(e) {
  e.preventDefault();
  const name = document.getElementById('regName').value.trim();
  const email = document.getElementById('regEmail').value.trim().toLowerCase();
  const pass = document.getElementById('regPassword').value;
  const confirm = document.getElementById('regConfirm').value;
  const role = document.getElementById('regRole').value;
  const address = document.getElementById('regAddress').value.trim();
  const houseCount = parseInt(document.getElementById('regHouseCount')?.value || '0', 10);

  if (pass !== confirm) { showAlert('regAlert', 'Passwords do not match.', 'danger'); return false; }
  if (pass.length < 8 || !/[A-Z]/.test(pass) || !/[a-z]/.test(pass) || !/[0-9]/.test(pass)) {
    showAlert('regAlert', 'Password must be at least 8 characters with upper, lower and a number.', 'danger');
    return false;
  }
  if (!['owner', 'tenant'].includes(role)) { showAlert('regAlert', 'Select Owner or Tenant.', 'danger'); return false; }
  if (role === 'owner' && (!houseCount || houseCount < 1)) {
    showAlert('regAlert', 'Enter number of houses for rent (minimum 1).', 'danger');
    return false;
  }
  if (address.length < 8) { showAlert('regAlert', 'Enter a complete house address.', 'danger'); return false; }

  let users = load(STORAGE.users, []);
  let houses = load(STORAGE.houses, []);
  if (users.some(u => u.email === email)) {
    showAlert('regAlert', 'This email is already registered.', 'danger');
    return false;
  }
  const reserved = ['eevannesswaran@gmail.com', 'etwo999@gmail.com', 'khavinesh424835@gmail.com'];
  if (reserved.includes(email)) {
    showAlert('regAlert', 'This email is reserved for system staff.', 'danger');
    return false;
  }

  const addressKey = address.toLowerCase().replace(/\s+/g, ' ');
  let houseId = null;
  if (role === 'owner') {
    const existing = houses.find(h => h.address.toLowerCase().replace(/\s+/g, ' ') === addressKey);
    if (existing && existing.ownerId) {
      showAlert('regAlert', 'This address is already claimed by an Owner.', 'danger');
      return false;
    }
    if (existing) houseId = existing.id;
    else {
      houseId = uid();
      houses.push({ id: houseId, address, ownerId: null, houseCount, created: now() });
    }
  } else {
    const existing = houses.find(h => h.address.toLowerCase().replace(/\s+/g, ' ') === addressKey && h.ownerId);
    if (!existing) {
      showAlert('regAlert', 'No Owner found for this address. Owner must register first.', 'danger');
      return false;
    }
    houseId = existing.id;
  }

  const newUser = {
    id: uid(), name, email, password: pass, role, houseId,
    houseCount: role === 'owner' ? houseCount : 0, active: true
  };
  users.push(newUser);
  if (role === 'owner') {
    const h = houses.find(x => x.id === houseId);
    if (h) { h.ownerId = newUser.id; h.houseCount = houseCount; }
  }
  save(STORAGE.users, users);
  save(STORAGE.houses, houses);
  logActivity('REGISTRATION', 'New ' + role + ': ' + name, name);
  showAlert('regAlert', 'Registration successful. You can sign in now.', 'success');
  setTimeout(function () {
    showLogin();
    document.getElementById('loginEmail').value = email;
    document.getElementById('loginPassword').value = '';
  }, 1000);
  return false;
}

function logActivity(action, details, userName) {
  const list = load(STORAGE.activity, []);
  list.unshift({
    id: uid(), action, details, time: now(),
    user: userName || (getCurrentUser() && getCurrentUser().name) || 'System'
  });
  if (list.length > 50) list.length = 50;
  save(STORAGE.activity, list);
}

function addAlert(message, severity) {
  severity = severity || 'warning';
  const list = load(STORAGE.alerts, []);
  list.unshift({ id: uid(), message, severity, read: false, time: now() });
  if (list.length > 30) list.length = 30;
  save(STORAGE.alerts, list);
}

function getTelegramConfig() {
  return load(STORAGE.telegram, { token: '', chatId: '' });
}

function saveTelegramSettings() {
  const token = (document.getElementById('tgToken') && document.getElementById('tgToken').value || '').trim();
  const chatId = (document.getElementById('tgChatId') && document.getElementById('tgChatId').value || '').trim();
  save(STORAGE.telegram, { token, chatId });
  if (token && chatId) {
    showToast('Telegram settings saved.', 'success');
    if (document.getElementById('cloudStatus')) document.getElementById('cloudStatus').textContent = 'READY';
    if (document.getElementById('cloudText')) document.getElementById('cloudText').textContent = 'Telegram active';
  } else showToast('Enter both Bot Token and Chat ID.', 'error');
}

function loadTelegramSettingsIntoForm() {
  const cfg = getTelegramConfig();
  if (document.getElementById('tgToken')) document.getElementById('tgToken').value = cfg.token || '';
  if (document.getElementById('tgChatId')) document.getElementById('tgChatId').value = cfg.chatId || '';
  if (cfg.token && cfg.chatId) {
    if (document.getElementById('cloudStatus')) document.getElementById('cloudStatus').textContent = 'READY';
    if (document.getElementById('cloudText')) document.getElementById('cloudText').textContent = 'Telegram active';
  }
}

async function sendTelegram(message) {
  const cfg = getTelegramConfig();
  if (!cfg.token || !cfg.chatId) {
    logActivity('TELEGRAM', 'Alert logged (Telegram not configured)', getCurrentUser() && getCurrentUser().name);
    showToast('Alert saved. Configure Telegram in Profile.', 'info');
    return false;
  }
  const url = 'https://api.telegram.org/bot' + encodeURIComponent(cfg.token) + '/sendMessage';
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: cfg.chatId, text: message, parse_mode: 'HTML' })
    });
    const data = await res.json().catch(function () { return {}; });
    if (data.ok) {
      logActivity('TELEGRAM', 'Notification sent', getCurrentUser() && getCurrentUser().name);
      showToast('Telegram notification sent.', 'success');
      return true;
    }
    throw new Error(data.description || 'API error');
  } catch (err) {
    console.warn(err);
    logActivity('TELEGRAM', 'Send failed', getCurrentUser() && getCurrentUser().name);
    showToast('Telegram send failed. Verify Bot Token and Chat ID.', 'error');
    return false;
  }
}

async function testTelegram() {
  await sendTelegram('Smart Home IoT\nTest notification.\nTime: ' + now());
}

function showToast(msg, type) {
  type = type || 'info';
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.className = 'toast show ' + (type === 'error' ? 'error' : type === 'success' ? 'success' : '');
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(function () { t.className = 'toast'; }, 3200);
}

function toggleSidebar() {
  const s = document.getElementById('sidebar');
  if (s) s.classList.toggle('open');
}

function initDashboard() {
  const user = getCurrentUser();
  if (!user) { window.location.href = 'index.html'; return; }

  document.getElementById('userName').textContent = user.name;
  document.getElementById('heroName').textContent = user.name;
  document.getElementById('profileName').textContent = user.name;
  document.getElementById('profileEmail').textContent = user.email;
  document.getElementById('userRole').textContent = user.role.toUpperCase().replace('_', ' ');
  document.getElementById('profileRole').textContent = roleLabel(user.role);
  document.getElementById('pageTitle').textContent = roleLabel(user.role) + ' Dashboard';

  const initial = user.name.charAt(0).toUpperCase();
  document.getElementById('userAvatar').textContent = initial;
  document.getElementById('profileAvatar').textContent = initial;

  const houses = load(STORAGE.houses, []);
  const house = houses.find(function (h) { return h.id === user.houseId; });
  var addressText = 'No house assigned';
  if (user.role === 'super_admin' || user.role === 'admin') addressText = 'System-wide access';
  else if (house) {
    addressText = house.address;
    if (user.role === 'owner' && (user.houseCount || house.houseCount)) {
      addressText += ' · ' + (user.houseCount || house.houseCount) + ' house(s) for rent';
    }
  }
  document.getElementById('houseAddress').textContent = addressText;

  document.querySelectorAll('.super-only').forEach(function (el) {
    el.style.display = user.role === 'super_admin' ? '' : 'none';
  });
  document.querySelectorAll('.admin-only').forEach(function (el) {
    el.style.display = canManageUsers(user.role) ? '' : 'none';
  });
  document.querySelectorAll('.owner-only').forEach(function (el) {
    el.style.display = user.role === 'owner' ? '' : 'none';
  });

  document.getElementById('activityTitle').textContent =
    canManageUsers(user.role) ? 'System Activity' : 'My Activity';

  document.querySelectorAll('.nav-item[data-section]').forEach(function (link) {
    link.addEventListener('click', function () {
      document.querySelectorAll('.nav-item').forEach(function (n) { n.classList.remove('active'); });
      link.classList.add('active');
      if (window.innerWidth <= 960) {
        var sb = document.getElementById('sidebar');
        if (sb) sb.classList.remove('open');
      }
    });
  });

  loadTelegramSettingsIntoForm();
  // Hide Administrator option unless Super Admin
  var addRole = document.getElementById('addRole');
  if (addRole && user.role !== 'super_admin') {
    Array.prototype.slice.call(addRole.options).forEach(function (opt) {
      if (opt.value === 'admin') opt.remove();
    });
  }
  refreshAll();
  setInterval(refreshSensors, 7000);
}

var DEVICE_META = {
  r1_light: { name: 'Room 1 Light', icon: '💡', pin: 'GPIO26' },
  r1_fan: { name: 'Room 1 Fan', icon: '🌀', pin: 'GPIO27' },
  r2_light: { name: 'Room 2 Light', icon: '💡', pin: 'GPIO32' },
  r2_fan: { name: 'Room 2 Fan', icon: '🌀', pin: 'GPIO33' }
};

function renderDevices() {
  const grid = document.getElementById('deviceGrid');
  if (!grid) return;
  const user = getCurrentUser();
  const perms = getPermissions(user.role);
  const state = load(STORAGE.devices, { r1_light: 0, r1_fan: 0, r2_light: 0, r2_fan: 0 });
  var html = '';
  Object.keys(DEVICE_META).forEach(function (key) {
    var meta = DEVICE_META[key];
    var isOn = !!state[key];
    var allowed = !!perms[key];
    html += '<div class="device-card ' + (isOn ? 'on' : '') + ' ' + (allowed ? '' : 'disabled') + '">' +
      '<div class="dev-icon">' + meta.icon + '</div>' +
      '<h3>' + meta.name + '</h3>' +
      '<div class="status-label ' + (isOn ? 'on' : '') + '">' + (isOn ? '● ON' : '○ OFF') + ' · ' + meta.pin + '</div>' +
      '<div class="device-actions">' +
      '<button class="btn primary sm" onclick="controlDevice(\'' + key + '\',\'on\')" ' + (allowed ? '' : 'disabled') + '>ON</button>' +
      '<button class="btn outline sm" onclick="controlDevice(\'' + key + '\',\'off\')" ' + (allowed ? '' : 'disabled') + '>OFF</button>' +
      '</div></div>';
  });
  grid.innerHTML = html;
}

function controlDevice(device, state) {
  const user = getCurrentUser();
  const perms = getPermissions(user.role);
  if (!perms[device]) { showToast('Access denied for this device.', 'error'); return; }
  const devices = load(STORAGE.devices, { r1_light: 0, r1_fan: 0, r2_light: 0, r2_fan: 0 });
  devices[device] = state === 'on' ? 1 : 0;
  save(STORAGE.devices, devices);
  var label = (DEVICE_META[device] && DEVICE_META[device].name) || device;
  logActivity('DEVICE_CONTROL', label + ' ' + state.toUpperCase(), user.name);
  showToast(label + ' turned ' + state.toUpperCase(), 'success');
  renderDevices();
}

function refreshSensors() {
  var motion = Math.random() > 0.88 ? 1 : 0;
  updateSensorUI(motion);
  if (motion === 1) {
    var alerts = load(STORAGE.alerts, []);
    var recent = alerts.find(function (a) {
      return (a.message.indexOf('Motion') >= 0 || a.message.indexOf('Presence') >= 0)
        && (Date.now() - new Date(a.time).getTime() < 120000);
    });
    if (!recent) {
      addAlert('Presence detected (ultrasonic zone).', 'warning');
      renderAlerts();
      updateAlertCount();
      sendTelegram('Smart Home Security\nPresence detected.\nTime: ' + now());
    }
  }
  if (document.getElementById('serverTime')) document.getElementById('serverTime').textContent = now();
  if (document.getElementById('lastSync')) document.getElementById('lastSync').textContent = 'Last synchronized: ' + now();
}

function updateSensorUI(motion) {
  var mv = document.getElementById('motionValue');
  if (mv) mv.textContent = motion === 1 ? 'DETECTED' : 'Clear';
  var icon = document.getElementById('motionIcon');
  if (icon) icon.classList.toggle('active', motion === 1);
}

function renderAlerts() {
  var list = document.getElementById('alertsList');
  if (!list) return;
  var alerts = load(STORAGE.alerts, []);
  if (!alerts.length) {
    list.innerHTML = '<div class="empty-state">No security alerts yet.</div>';
    return;
  }
  list.innerHTML = alerts.map(function (a) {
    return '<div class="alert-item ' + (a.read ? '' : 'unread') + '"><div>' +
      '<span class="sev ' + a.severity + '">' + a.severity + '</span>' +
      '<span style="margin-left:0.5rem">' + esc(a.message) + '</span>' +
      '<small style="display:block;color:var(--muted);margin-top:0.2rem">' + esc(a.time) + '</small></div>' +
      (!a.read ? '<button class="text-btn" onclick="markAlertRead(\'' + a.id + '\')">Mark read</button>' : '') +
      '</div>';
  }).join('');
}

function markAlertRead(id) {
  var alerts = load(STORAGE.alerts, []);
  var a = alerts.find(function (x) { return x.id === id; });
  if (a) a.read = true;
  save(STORAGE.alerts, alerts);
  renderAlerts();
  updateAlertCount();
}

function markAllAlertsRead() {
  var alerts = load(STORAGE.alerts, []);
  alerts.forEach(function (a) { a.read = true; });
  save(STORAGE.alerts, alerts);
  renderAlerts();
  updateAlertCount();
  showToast('All alerts marked as read.', 'success');
}

function updateAlertCount() {
  var unread = load(STORAGE.alerts, []).filter(function (a) { return !a.read; }).length;
  var el = document.getElementById('alertCount');
  if (el) el.textContent = unread;
}

function renderActivity() {
  var list = document.getElementById('activityList');
  if (!list) return;
  var user = getCurrentUser();
  var items = load(STORAGE.activity, []);
  if (!canManageUsers(user.role)) items = items.filter(function (a) { return a.user === user.name; });
  if (!items.length) {
    list.innerHTML = '<div class="empty-state">No activity yet.</div>';
    return;
  }
  list.innerHTML = items.slice(0, 15).map(function (a) {
    return '<div class="activity-item"><div><strong>' + esc(a.action) + '</strong>' +
      (a.details ? ' – ' + esc(a.details) : '') +
      '<small>' + esc(a.user) + ' · ' + esc(a.time) + '</small></div></div>';
  }).join('');
}

function renderUsers() {
  var tbody = document.getElementById('userTableBody');
  if (!tbody) return;
  var me = getCurrentUser();
  var users = load(STORAGE.users, []);
  var houses = load(STORAGE.houses, []);

  tbody.innerHTML = users.map(function (u) {
    var house = houses.find(function (h) { return h.id === u.houseId; });
    var houseInfo = '—';
    if (house) {
      houseInfo = esc(house.address);
      if (u.role === 'owner' && (u.houseCount || house.houseCount)) {
        houseInfo += '<br><small>' + (u.houseCount || house.houseCount) + ' house(s)</small>';
      }
    }
    var actions = '—';
    if (u.id !== me.id && u.role !== 'super_admin') {
      var canTouchAdmin = canManageAdmins(me.role) && u.role === 'admin';
      var canTouchResident = canManageUsers(me.role) && (u.role === 'owner' || u.role === 'tenant');
      if (canTouchAdmin || canTouchResident) {
        actions = '<div class="actions">';
        actions += '<button class="btn outline sm" onclick="toggleUser(\'' + u.id + '\')">' + (u.active ? 'Deactivate' : 'Activate') + '</button>';
        actions += '<button class="btn danger sm" onclick="deleteUser(\'' + u.id + '\',\'' + esc(u.name) + '\')">Delete</button>';
        actions += '</div>';
      }
    }
    var badgeClass = (u.role === 'super_admin' || u.role === 'admin') ? 'admin' : u.role;
    return '<tr><td><strong>' + esc(u.name) + '</strong></td><td>' + esc(u.email) + '</td>' +
      '<td><span class="badge ' + badgeClass + '">' + esc(u.role) + '</span></td>' +
      '<td>' + houseInfo + '</td>' +
      '<td><span class="badge ' + (u.active ? 'active' : 'inactive') + '">' + (u.active ? 'Active' : 'Inactive') + '</span></td>' +
      '<td>' + actions + '</td></tr>';
  }).join('');

  var countEl = document.getElementById('userCount');
  if (countEl) countEl.textContent = users.length;
}

function toggleUser(id) {
  var me = getCurrentUser();
  if (!canManageUsers(me.role)) return;
  var users = load(STORAGE.users, []);
  var u = users.find(function (x) { return x.id === id; });
  if (!u || u.role === 'super_admin') return;
  if (u.role === 'admin' && !canManageAdmins(me.role)) {
    showToast('Only Super Admin can change Administrator accounts.', 'error');
    return;
  }
  u.active = !u.active;
  save(STORAGE.users, users);
  logActivity(u.active ? 'USER_ACTIVATED' : 'USER_DEACTIVATED', u.name, me.name);
  showToast(u.active ? 'User activated.' : 'User deactivated.', 'success');
  renderUsers();
}

function deleteUser(id, name) {
  var me = getCurrentUser();
  if (!canManageUsers(me.role)) return;
  if (!confirm('Delete user "' + name + '"? This cannot be undone.')) return;
  var users = load(STORAGE.users, []);
  var u = users.find(function (x) { return x.id === id; });
  if (!u || u.role === 'super_admin') {
    showToast('Cannot delete Super Administrator.', 'error');
    return;
  }
  if (u.role === 'admin' && !canManageAdmins(me.role)) {
    showToast('Only Super Admin can delete Administrators.', 'error');
    return;
  }
  users = users.filter(function (x) { return x.id !== id; });
  save(STORAGE.users, users);
  logActivity('USER_DELETED', u.role + ': ' + name, me.name);
  showToast('User deleted.', 'success');
  renderUsers();
  refreshAll();
}

function addUserFromForm(e) {
  e.preventDefault();
  var me = getCurrentUser();
  if (!canManageUsers(me.role)) { showToast('Access denied.', 'error'); return false; }

  var name = document.getElementById('addName').value.trim();
  var email = document.getElementById('addEmail').value.trim().toLowerCase();
  var pass = document.getElementById('addPass').value;
  var role = document.getElementById('addRole').value;

  if (!name || !email || !pass || !role) { showToast('Fill all fields.', 'error'); return false; }
  if (pass.length < 8) { showToast('Password must be at least 8 characters.', 'error'); return false; }
  if (role === 'admin' && !canManageAdmins(me.role)) {
    showToast('Only Super Admin can create Administrators.', 'error');
    return false;
  }
  if (role === 'super_admin') {
    showToast('Cannot create another Super Administrator from the panel.', 'error');
    return false;
  }

  var users = load(STORAGE.users, []);
  if (users.some(function (u) { return u.email === email; })) {
    showToast('Email already exists.', 'error');
    return false;
  }

  users.push({
    id: uid(), name: name, email: email, password: pass, role: role,
    houseId: null, houseCount: 0, active: true
  });
  save(STORAGE.users, users);
  logActivity('USER_CREATED', role + ': ' + name + ' (' + email + ')', me.name);
  showToast(roleLabel(role) + ' account created.', 'success');
  var form = document.getElementById('addUserForm');
  if (form) form.reset();
  renderUsers();
  refreshAll();
  return false;
}

function renderHouses() {
  var tbody = document.getElementById('houseTableBody');
  if (!tbody) return;
  var houses = load(STORAGE.houses, []);
  var users = load(STORAGE.users, []);
  if (!houses.length) {
    tbody.innerHTML = '<tr><td colspan="5" class="empty-table">No houses registered yet.</td></tr>';
    return;
  }
  tbody.innerHTML = houses.map(function (h) {
    var owner = users.find(function (u) { return u.id === h.ownerId; });
    var tenants = users.filter(function (u) { return u.houseId === h.id && u.role === 'tenant'; }).length;
    return '<tr><td><strong>' + esc(h.address) + '</strong></td><td>' + (h.houseCount || 1) + '</td>' +
      '<td>' + (owner ? esc(owner.name) + '<br><small>' + esc(owner.email) + '</small>' : '<span class="muted">Unclaimed</span>') + '</td>' +
      '<td>' + tenants + '</td><td>' + esc(h.created) + '</td></tr>';
  }).join('');
}

function releaseHouse() {
  if (!confirm('Release this house address?')) return;
  var user = getCurrentUser();
  var houses = load(STORAGE.houses, []);
  var users = load(STORAGE.users, []);
  var h = houses.find(function (x) { return x.id === user.houseId; });
  if (h) h.ownerId = null;
  var u = users.find(function (x) { return x.id === user.id; });
  if (u) { u.houseId = null; u.houseCount = 0; }
  save(STORAGE.houses, houses);
  save(STORAGE.users, users);
  user.houseId = null;
  user.houseCount = 0;
  setSession(user);
  logActivity('HOUSE_RELEASED', 'Owner released address', user.name);
  showToast('House address released.', 'success');
  setTimeout(function () { location.reload(); }, 800);
}

function refreshAll() {
  renderDevices();
  refreshSensors();
  renderAlerts();
  renderActivity();
  updateAlertCount();
  var user = getCurrentUser();
  if (user && canManageUsers(user.role)) {
    renderUsers();
    renderHouses();
  }
  if (document.getElementById('systemStatus')) document.getElementById('systemStatus').textContent = 'ONLINE';
  if (document.getElementById('lastSync')) document.getElementById('lastSync').textContent = 'Last synchronized: ' + now();
}

function clearAllData() {
  if (!confirm('Clear local session data on this device?')) return;
  Object.keys(STORAGE).forEach(function (k) { localStorage.removeItem(STORAGE[k]); });
  initSystemAdmins();
  logout();
}
