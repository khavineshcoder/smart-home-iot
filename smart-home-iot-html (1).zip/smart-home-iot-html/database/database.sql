-- =============================================================================
-- Smart Home IoT Management System
-- Database Schema (MySQL / MariaDB – XAMPP compatible)
-- Version 2.1 – matches HTML/JS logical data model
-- =============================================================================
--
-- How to use with XAMPP:
--   1. Start Apache + MySQL
--   2. Open phpMyAdmin → Import this file
--      OR run: mysql -u root < database.sql
--
-- Character set: utf8mb4 (supports full Unicode)
-- Engine: InnoDB (supports foreign keys & transactions)
-- =============================================================================

CREATE DATABASE IF NOT EXISTS smart_home_iot
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE smart_home_iot;

-- -----------------------------------------------------------------------------
-- Table: houses
-- Stores registered properties. Owner claims one primary address.
-- house_count = number of units the owner is renting out.
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS houses (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  address       VARCHAR(255) NOT NULL,
  address_key   VARCHAR(255) NOT NULL UNIQUE COMMENT 'Normalized lowercase address for uniqueness',
  owner_id      INT UNSIGNED NULL,
  house_count   INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'Number of houses/units for rent',
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_houses_owner (owner_id)
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- Table: users
-- Roles: admin | owner | tenant
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name           VARCHAR(100) NOT NULL,
  email          VARCHAR(190) NOT NULL UNIQUE,
  password_hash  VARCHAR(255) NOT NULL COMMENT 'bcrypt / password_hash()',
  role           ENUM('admin','owner','tenant') NOT NULL,
  house_id       INT UNSIGNED NULL,
  house_count    INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Copied from houses for owner quick access',
  is_active      TINYINT(1) NOT NULL DEFAULT 1,
  last_login     DATETIME NULL,
  created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_users_role (role),
  INDEX idx_users_house (house_id),
  CONSTRAINT fk_users_house
    FOREIGN KEY (house_id) REFERENCES houses(id)
    ON DELETE SET NULL
) ENGINE=InnoDB;

-- Owner FK on houses (added after users exists to avoid circular create order)
ALTER TABLE houses
  ADD CONSTRAINT fk_houses_owner
  FOREIGN KEY (owner_id) REFERENCES users(id)
  ON DELETE SET NULL;

-- -----------------------------------------------------------------------------
-- Table: devices
-- Logical device state (device channel mapping for appliance control)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS devices (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  device_key   VARCHAR(30) NOT NULL UNIQUE COMMENT 'light | fan | main',
  device_name  VARCHAR(80) NOT NULL,
  pin          VARCHAR(10) NOT NULL COMMENT 'Device channel e.g. V0 / CH1',
  state        TINYINT(1) NOT NULL DEFAULT 0 COMMENT '0=OFF, 1=ON',
  updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO devices (device_key, device_name, pin, state) VALUES
  ('light', 'Smart Light', 'V0', 0),
  ('fan',   'Smart Fan',   'V1', 0),
  ('main',  'Main Switch', 'V2', 1)
ON DUPLICATE KEY UPDATE
  device_name = VALUES(device_name),
  pin = VALUES(pin);

-- -----------------------------------------------------------------------------
-- Table: login_attempts
-- Used for rate limiting (brute-force protection)
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS login_attempts (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  email         VARCHAR(190) NOT NULL,
  ip_address    VARCHAR(45) NOT NULL,
  success       TINYINT(1) NOT NULL DEFAULT 0,
  attempted_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_login_email_time (email, attempted_at),
  INDEX idx_login_ip_time (ip_address, attempted_at)
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- Table: activity_logs
-- Audit trail of user actions
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS activity_logs (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NULL,
  action      VARCHAR(100) NOT NULL,
  details     VARCHAR(500) NULL,
  ip_address  VARCHAR(45) NULL,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_activity_user (user_id),
  INDEX idx_activity_time (created_at),
  CONSTRAINT fk_activity_user
    FOREIGN KEY (user_id) REFERENCES users(id)
    ON DELETE SET NULL
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- Table: security_alerts
-- PIR motion and other security events
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS security_alerts (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  house_id    INT UNSIGNED NULL,
  alert_type  VARCHAR(50) NOT NULL COMMENT 'motion | system | other',
  message     VARCHAR(500) NOT NULL,
  severity    ENUM('info','warning','critical') NOT NULL DEFAULT 'warning',
  is_read     TINYINT(1) NOT NULL DEFAULT 0,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_alert_house (house_id),
  INDEX idx_alert_read (is_read),
  CONSTRAINT fk_alerts_house
    FOREIGN KEY (house_id) REFERENCES houses(id)
    ON DELETE SET NULL
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- Table: sensor_readings
-- Historical temperature / humidity / motion samples
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sensor_readings (
  id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  house_id     INT UNSIGNED NULL,
  motion       TINYINT(1) NULL,
  -- temperature removed (not on hardware),
  -- humidity removed (not on hardware),
  source       VARCHAR(30) NOT NULL DEFAULT 'local' COMMENT 'local | sensor',
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_sensor_house_time (house_id, created_at),
  CONSTRAINT fk_sensor_house
    FOREIGN KEY (house_id) REFERENCES houses(id)
    ON DELETE SET NULL
) ENGINE=InnoDB;

-- -----------------------------------------------------------------------------
-- Seed authorised system administrators
-- Passwords below are PLAINTEXT placeholders for documentation only.
-- In a real PHP server they MUST be stored with password_hash().
-- Current HTML demo uses the plaintext values in localStorage for simplicity.
-- -----------------------------------------------------------------------------
-- Emails & intended passwords (document only – do not use as real hashes):
--   eevannesswaran@gmail.com     → Ev@nNess#2026$IoT!
--   etwo999@gmail.com            → EtWo999#Secure$26!
--   khavinesh424835@gmail.com    → Kh@viNe5h#4248$IoT
--
-- Example (PHP side):
--   password_hash('Ev@nNess#2026$IoT!', PASSWORD_DEFAULT)
-- -----------------------------------------------------------------------------

-- Optional: create admin rows with dummy bcrypt hashes of the passwords above.
-- Generate real hashes with PHP: echo password_hash('...', PASSWORD_DEFAULT);
-- The hashes below are illustrative bcrypt for the three passwords.

INSERT INTO users (name, email, password_hash, role, house_id, house_count, is_active) VALUES
(
  'Eevannesswaran',
  'eevannesswaran@gmail.com',
  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',  -- REPLACE with real hash
  'admin', NULL, 0, 1
),
(
  'Etwo',
  'etwo999@gmail.com',
  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',  -- REPLACE with real hash
  'admin', NULL, 0, 1
),
(
  'Khavinesh',
  'khavinesh424835@gmail.com',
  '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',  -- REPLACE with real hash
  'admin', NULL, 0, 1
)
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- =============================================================================
-- END OF SCHEMA
-- =============================================================================
